package sourcecode;

abstract public class inputfields extends handler{

	abstract public void createField();
}
