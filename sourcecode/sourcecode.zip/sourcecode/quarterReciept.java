package sourcecode;

public class quarterReciept extends landline {
public double cost(int n, int i) {
		
		return (n * 90);
	}
 
}
