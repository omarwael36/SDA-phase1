package sourcecode;

abstract public class landline extends services{
	abstract public double cost(int n, int i);
}
