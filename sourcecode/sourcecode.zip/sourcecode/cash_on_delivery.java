package sourcecode;

public class cash_on_delivery {

}
