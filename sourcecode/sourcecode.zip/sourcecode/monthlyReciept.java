package sourcecode;

public class monthlyReciept extends landline {
	public double cost(int n,int i) {
		
		return (n * 30);
	}
	
}
