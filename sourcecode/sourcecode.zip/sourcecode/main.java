package sourcecode;


public class main {
	public static void main(String[] args) {
        System.out.println("Messi weino kassarna 3eino!!!"); 
		System.out.println("Ankara messi ankara messi goal goal goal !!!");
    }
}
